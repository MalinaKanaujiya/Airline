<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="ab.css">
</head>
<body>
<?php include 'nav.php'?>
    <div class="about">
        <div class="destination">
            <div class="img">
                <img src="img/view.jpg" alt="">
            </div>
           <p1> <h1>Roads are often diffucult but destination is always beutiful</h1> <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Expedita, repellat fuga. Corrupti ex illum ullam, corporis esse architecto ducimus voluptas, rem repudiandae perspiciatis facere dolorum consequuntur. Autem tempora mollitia facilis.</p></p1>
           
        </div>
        <div class="information">
            <p><h1>Difficult road often lead to beautiful destination </h1><br><br><p>Or airline system helps you to provide you safe journy </p><br><p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nesciunt soluta dignissimos saepe excepturi repellendus, inventore deserunt culpa commodi quas explicabo, provident itaque perspiciatis! Cupiditate adipisci eius accusamus molestiae! Ratione, reiciendis.</p></p>
            

            <img src="img/4.jpg" alt="">
        </div>
    </div>
    <?php include'footer.php'?>
</body>
</html>