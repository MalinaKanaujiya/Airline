
<?php
$servername = "localhost";
$username = "root";
$password = "";
$db = "airlines";
$cnn = mysqli_connect($servername, $username, $password, $db);
?>