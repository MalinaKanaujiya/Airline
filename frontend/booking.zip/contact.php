<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body, html {
        background: url(img/12.jpg) no-repeat center center/cover;
        color:#111;
        margin: 0;
        padding:5px;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    } 
  
    body{
        text-align: center;
        font-size:20px; 
         font-weight: bold;   
        
    }
   h1{
       color:#111;
   }
    
    span{
        display: block;
        font-size: 30px;
        color: rgb(7, 1, 27);
        font-weight: bold;
    }
     </style>
</head>
 <body>
 <?php include 'nav.php'?>
        <h1>Contact</h2>
        <p><span>Airline Reservation System</span> Kathmandu,Nepal</p> 
  
   
<div class="form">
   
    
</div>
<div class="info">
    
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Iure voluptatum, quia eligendi, voluptate ducimus ex ipsum quidem aut enim repellendus molestias alias aspernatur rem cum obcaecati eius rerum assumenda odio.</p>
    <form action="">
        Tel No: 9840001457<br><br>
        Fax: 9840013786<br><br>
        E-mail: airlinereservation@gmail.com<br><br>
        For Online Ticketing issues:ticketbooking@gmail.com<br><br>
        
    </form>
    
</div>
    
   
    

       
   
</body>

    
</html>