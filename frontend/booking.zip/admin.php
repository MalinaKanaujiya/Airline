<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
  <link rel="stylesheet" href="admin.css">
</head>
<body>
    <div class="container">
        <div class="logo">
                    <h3>Airline</h3>
                </div>
                <div class="home">
                    <a href="schel.php">Flight schedule <option value="">
                        <!-- <select name="update" id="update">Update Flight  </select> -->
                    </option></a>
                    <a href="#">Destination</a>
                    <a href="#">customer info</a>
                </div>
            </div>
            <div class="img">
                <img src="img/view.jpg" alt="">
            </div>

    
</body>
</html>