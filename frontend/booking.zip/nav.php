<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
        <div class="navbar">
            <div class="main">
                <div class="one">
                  <p></p>
                </div>
                <div class="two">
                    <a href="loginadmin.php">Admin Login</a>
                    <a href="userlogin.php">User Login</a>
                </div>
                </div>
               <div class="second">
                <div class="logo">
                    <h3>Airline</h3>
                </div>
                <div class="home">
                <a href="index.php">Home</a>
                    <a href="book.php">Booking</a>
                    <a href="about.php">About</a>
                    <a href="schedule.php">Schedule</a>
                    <a href="#">Destination</a>
                    <a href="contact.php">Contact</a>
                    
                </div>
                <div class="search">
                    <input type="text" placeholder="Search..." value="       Search.....">
                </div>
               </div>
        </div>

</body>
</html>