<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .foot{
            text-align: center;
            background-color:#333;
            color:white;
        }
    </style>
</head>
<body>
    <div class="foot">
        <h3>Airline</h3><br>
            <form action="">
                Tel No: 9840001457<br><br>
                Fax: 9840013786<br><br>
                E-mail: airlinereservation@gmail.com<br><br>
                For Online Ticketing issues:ticketbooking@gmail.com<br><br>
                 </form>
                 <footer id="main-footer">
      <p>Airline &copy; 2020 All Right Reserved</p>
  </footer>
    </div>
</body>
</html>