<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="book.css">
</head>
<body>
<?php include 'nav.php'?>
<div class="main">
    <div class="con">
       <img src="img/7.jpg" alt="">
    </div>
    <div class="location">

    
       <form action="booking.php" method="POST">
           
            <p>
                <input type="radio"name="flight" value="one">oneway
                <input type="radio" name="flight"value="round">round trip
            </p>
           <p>from <br>
               
               <select name="from">
                   <option value="Dhang" name="from">Dhang</option>
                   <option value="Kathmandu" name="from">Kathmandu</option>
                   <option value="Pokhara" name="from">Pokhara</option>
                   <option value=""selected disabled hidden name="from">--From--</option>
                   <option value="Simara" name="from">Simara</option>
               </select>
           </p>
           <p>To <br>
               <select name="des" id="" enctype = "multipart/form-data">
                   <option value="pokhara" name="des">pokhara</option>
                   <option value="kathmandu" name="des">kathmandu</option>
                   <option value="Dhang" name="des">Dhang</option>
                   <option value=""selected disabled hidden name="des">--To--</option>
                   <option value="pokhara" name="des">pokhara</option>
               </select>
           </p>
           <p>Departure Date <br>
               <input type="Date" name="ddate">
           </p>
           <p>Returning<br>
            <input type="Date" name="rdate">
        </p>
        <p>Adult <br>
            <input type="number" name="adult">
        </p>
        <p>child <br>
            <input type="number" name="child">
        </p>
        <p>Naionality <br>
            <select name="nation" id="">
            <option value="Neplease"  name="nation" >Neplease</option>
            <option value="Indian"  name="nation" >Indian</option>
           
            <option value=""selected disabled hidden name="nation">Select Nationality</option>
            
        </select>
        </p>
        <p>
        <input type="submit"value="Submit" name='save'><br><br>
            
        </p>
        </form>
    </div>
    <div class="image">
        <img src="img/4.jpg" alt="">
    </div>
   
</div>
<?php include'footer.php'?>
</body>
<!-- <script>
function validate()
{
if (document.getElementById("password").value != document.getElementById("confirmpassword").value)
{
    alert("Password verification mismatch");
    return false;
}
else
return true;
}
</script> -->
</html>